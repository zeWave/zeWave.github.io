InputStream Adaptive is provided under

    SPDX-License-Identifier: GPL-2.0-or-later


Being under the terms of the GNU General Public License v2.0 or later, according with

    LICENSES/GPL-2.0-or-later


In addition, other licenses may also apply. Please see

    LICENSES/README.md

for more details.

